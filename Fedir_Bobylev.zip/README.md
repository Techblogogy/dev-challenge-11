To Start this app you must have NPM.
Use following NPM commands:

npm init
npm start

Local server with address http://localhost:3000/ should start
